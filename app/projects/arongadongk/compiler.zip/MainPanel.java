//package library;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;

public class MainPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public MainPanel(Console c, Grid g) {
		this.setLayout(new BorderLayout());
		this.setBackground(Color.black);
		this.add(g, BorderLayout.CENTER);
		this.add(c, BorderLayout.SOUTH);
	}



	

}
