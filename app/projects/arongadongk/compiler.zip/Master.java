//package library;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.*;
import java.util.Random;
import java.util.ArrayList;
import java.util.Collections;
//import library.*;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Master {

	public static Grid _grid;
	public static Console _console;
	private static int _delay = 45;
	private static boolean _shouldRun = true;
	private static Random rand = new Random();
	private static javax.swing.Timer _t;
	private static ArrayList<Integer> methodList = new ArrayList<Integer>();
	
	static private boolean agd_addInt(int i)
	{
		methodList.add(i);
		Collections.shuffle(methodList);
		return true;
	}
	
	static private int agd_getInt()
	{
		int n;
		if (methodList.isEmpty())
		{ 
			n = -1;
		}
		else
		{
			n = methodList.get(0);
			methodList.remove(0);
		}
		return n;
	}
	
	static private String agd_intToString(int input)
	{
		return input + "";
	}
	
	static private String agd_floatToString(double input)
	{
		return input + "";
	}
	
	static private String agd_boolToString(boolean input)
	{
		return input?"true":"false";
	}
	
	static private double agd_randomFloat(double min, double max)
	{
		return rand.nextDouble()*(max-min) + min;
	}
	
	static private boolean agd_println(String s){
		_console.addTextln(s);
		return true;
	} 
	
	static private boolean agd_print(String s){
		_console.addText(s);
		return true;
	} 
	
	static private boolean agd_printlnInt(int n){
		return agd_println(n + "");
	} 
	
	static private boolean agd_printInt(int n){
		return agd_print(n + "");
	}
	
	static private boolean agd_printlnFloat(Float f){
		return agd_println(f + "");
	} 
	
	static private boolean agd_printFloat(Float f){
		return agd_print(f + "");
	}
	
	static private int agd_randomInt(int min, int max)
	{
		 int i = rand.nextInt(max-min+1) + min;
		 if(i < 0){
		 	return -i;
		 }
		 return i;
	}
	
	static private boolean agd_randomBool()
	{
		return rand.nextInt()%1 == 0;
	}
	
	static private boolean agd_clearGrid()
	{
		_grid.reset();
		return true;
	}
	
	static private boolean agd_setGridBorderColor(String color)
	{
		String temp = color.toLowerCase();

		if(temp.equals("red"))
			_grid.setBorderColor(Color.RED);
			
		else if(temp.equals("black"))
			_grid.setBorderColor(Color.BLACK);
			
		else if(temp.equals("blue"))
			_grid.setBorderColor(Color.BLUE);
			
		else if(temp.equals("cyan") || temp.equals("babyblue"))
			_grid.setBorderColor(Color.CYAN);
			
		else if(temp.equals("dark gray") || temp.equals("dark_gray") || temp.equals("darkgray"))
			_grid.setBorderColor(Color.DARK_GRAY);
			
		else if(temp.equals("gray"))
			_grid.setBorderColor(Color.GRAY);
			
		else if(temp.equals("green"))
			_grid.setBorderColor(Color.GREEN);
			
		else if(temp.equals("light gray") || temp.equals("light_gray") || temp.equals("lightgray"))
			_grid.setBorderColor(Color.LIGHT_GRAY);
			
		else if(temp.equals("magneta"))
			_grid.setBorderColor(Color.MAGENTA);
			
		else if(temp.equals("orange"))
			_grid.setBorderColor(Color.ORANGE);
			
		else if(temp.equals("pink"))
			_grid.setBorderColor(Color.PINK);
			
		else if(temp.equals("red"))
			_grid.setBorderColor(Color.RED);
			
		else if(temp.equals("white"))
			_grid.setBorderColor(Color.WHITE);
			
		else if(temp.equals("yellow"))
			_grid.setBorderColor(Color.YELLOW);
			
		else if(color.charAt(0) == '#' && color.length() == 7)
		{
			int tempI = Integer.parseInt(color.substring(1, 7),16);
			_grid.setBorderColor(new Color(tempI));
		} else {
			return false;
		}	
		return true;
	}

		static private String appendZero(String s,int max){
		String b = "";
		int l = s.length();
		for(int i = 0; i < max -l; i++){
			b += "0";
		}
		return b + s;
	}
	
	static private String agd_getGridColor(int x, int y)
	{
		if(x >= _grid.x){
			return "No Color";
		}
		if(y >= _grid.y){
			return "No Color";
		}
		if(x < 0){
			return "No Color";
		}
		if(y < 0){
			return "No Color";
		}
		String s = "#";
		Color c = _grid.getGridColor(x, y);
	
		s+= appendZero(java.lang.Integer.toHexString(c.getGreen()), 2);
		s+= appendZero(java.lang.Integer.toHexString(c.getRed()), 2);
		s+= appendZero(java.lang.Integer.toHexString(c.getBlue()), 2);
		
		return s;
	}
	
	static private boolean agd_setDelay(int d)
	{
		_delay = d;
		//_t.setDelay(d);
		return false;
	}
	
	static private boolean agd_setGridSize(int width, int height)
	{
		//_grid.setX(width);
		//_grid.setY(height);
		return false;
	}

	static private int agd_getHeight()
	{
		return _grid.y;
	}

	static private int agd_getWidth()
	{
		return _grid.x;
	}

	static private boolean agd_setGridColor(int x, int y, String color)
	{
		Color c = null;
		
		String temp = color.toLowerCase();

		if(temp.equals("red"))
			c = Color.RED;
			
		else if(temp.equals("black"))
			c = Color.BLACK;
			
		else if(temp.equals("blue"))
			c = Color.BLUE;
			
		else if(temp.equals("cyan") || temp.equals("babyblue"))
			c = Color.CYAN;
			
		else if(temp.equals("dark gray") || temp.equals("dark_gray") || temp.equals("darkgray"))
			c = Color.DARK_GRAY;
			
		else if(temp.equals("gray"))
			c = Color.GRAY;
			
		else if(temp.equals("green"))
			c = Color.GREEN;
			
		else if(temp.equals("light gray") || temp.equals("light_gray") || temp.equals("lightgray"))
			c = Color.LIGHT_GRAY;
			
		else if(temp.equals("magneta"))
			c = Color.MAGENTA;
			
		else if(temp.equals("orange"))
			c = Color.ORANGE;
			
		else if(temp.equals("pink"))
			c = Color.PINK;
			
		else if(temp.equals("red"))
			c = Color.RED;
			
		else if(temp.equals("white"))
			c = Color.WHITE;
			
		else if(temp.equals("yellow"))
			c = Color.YELLOW;
			
		else if(color.charAt(0) == '#' && color.length() == 7)
		{
			int tempI = Integer.parseInt(color.substring(1, 7),16);
			c = new Color(tempI);
		} else {
			return false;
		}	
		
		_grid.setGridColor(x, y, c);
		
		return true;
	}
	
	
	public static void main(String[] args){

	
		JFrame window = new JFrame("Implementation of Arongadongk");
		_grid = new Grid();
		_console = new Console();
		
		MainPanel main = new MainPanel(_console, _grid);
		window.setContentPane(main);
		window.pack();  // Set size of window to preferred size of its contents.
		window.setResizable(false);  // User can't change the window's size.
		window.setLocation(100,100);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setVisible(true);
		/*
		_t = new javax.swing.Timer(_delay, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!agd_action_1())
				{
					_t.stop();// _shouldRun = false;
				}
				
				_grid.repaint();
			}
		});
		*/
		if (!agd_setup_1())
		{
			//_t.start();
			System.exit(1);
		}
		
		while (agd_action_1() == true)
		{
		
		try {
			Thread.sleep(_delay);
			} catch(InterruptedException e){
				e.printStackTrace();
			}
			_grid.repaint();
			
		}
		
		
	}
	// code will come hereafter	
	public static String agd_Kim = "dum";
	public static double agd_pi = 3.1415927;
	public static double agd_Pi = 3.1415927;
	public static double agd_pI = 3.1415927;
	public static double agd_PI = 3.1415927;


    private static boolean agd_rasmusDead_1 = false;

    private static boolean agd_rasmus2Dead_1 = false;

    private static boolean agd_bjarkeDead_1 = false;

    private static int agd_rasmusX_1 = 0;

    private static int agd_rasmusY_1 = 0;

    private static int agd_rasmusC_1 = 0;

    private static int agd_rasmusS_1 = 0;

    private static String agd_standardColor_1 = "";

    private static int agd_rasmusDirection_1 = 0;

    private static int agd_rasmus2X_1 = 0;

    private static int agd_rasmus2Y_1 = 0;

    private static int agd_rasmus2Direction_1 = 0;

    private static int agd_bjarkeTronY_1 = 0;

    private static int agd_bjarkeTronX_1 = 0;

    private static int agd_bjarkeDirection_1 = 0;

    private static int agd_amountOfTrons_1 = 0;

    private static String agd_winner_1 = "";

    private static int agd_countOfGames_1 = 0;

    private static int agd_maxGames_1 = 0;

    private static int agd_bjarkeWins_1 = 0;

    private static int agd_rasmusWins_1 = 0;

    private static int agd_rasmus2Wins_1 = 0;

    private static int agd_ties_1 = 0;

    private static int agd_rasmusML_1 = 0;

    private static int agd_ticks_1 = 0;

    private static int agd_numOfTronsLeft_1 = 0;

    private static boolean agd_setup_1()
    {
        agd_amountOfTrons_1 = 0;
        agd_rasmusX_1 = agd_randomInt(0, agd_getWidth() - 1);
        agd_rasmusY_1 = agd_randomInt(0, agd_getHeight() - 1);
        agd_rasmusDirection_1 = agd_randomInt(0, 3);
        agd_setGridColor(agd_rasmusX_1, agd_rasmusY_1, "yellow");
        agd_amountOfTrons_1 = agd_amountOfTrons_1 + 1;
        agd_rasmusML_1 = 0;
        agd_rasmus2X_1 = agd_randomInt(0, agd_getWidth() - 1);
        agd_rasmus2Y_1 = agd_randomInt(0, agd_getHeight() - 1);
        agd_rasmus2Direction_1 = 1;
        agd_rasmusWins_1 = 0;
        agd_rasmus2Wins_1 = 0;
        agd_bjarkeTronY_1 = agd_randomInt(0, agd_getHeight() - 1);
        agd_bjarkeTronX_1 = agd_randomInt(0, agd_getWidth() - 1);
        agd_bjarkeDirection_1 = agd_randomInt(0, 3);
        agd_bjarkeWins_1 = 0;
        agd_setGridColor(agd_bjarkeTronX_1, agd_bjarkeTronY_1, "red");
        agd_amountOfTrons_1 = agd_amountOfTrons_1 + 1;
        agd_standardColor_1 = agd_getGridColor(5, 5);
        agd_countOfGames_1 = 0;
        agd_maxGames_1 = 1000;
        agd_setDelay(20);
        agd_ticks_1 = 0;
        agd_numOfTronsLeft_1 = agd_amountOfTrons_1;
        return true;
    }

    private static boolean agd_action_1()
    {
        agd_rasmus2Dead_1 = true;
        agd_ticks_1 = agd_ticks_1 + 1;
        if(agd_numOfTronsLeft_1 < 2)
        {
            agd_roundFinished_1();
        }
        agd_addInt(0);
        agd_addInt(1);
        agd_addInt(2);
        int agd_n_3 = 0;
        agd_n_3 = agd_getInt();
        while (agd_n_3 >= 0)
        {
            if(agd_n_3 == 0)
            {
                if( !(agd_rasmusDead_1))
                {
                    agd_rasmusTron_1();
                }
            }
            if(agd_n_3 == 1)
            {
                if( !(agd_bjarkeDead_1))
                {
                    agd_bjarkeTron_1();
                }
            }
            if(agd_n_3 == 2)
            {
                if( !(agd_rasmus2Dead_1))
                {
                }
            }
            agd_n_3 = agd_getInt();
        }
        if(agd_countOfGames_1 >= agd_maxGames_1)
        {
            int agd_k_5 = 0;
            agd_k_5 = agd_getHeighestNumOfWins_1(agd_rasmusWins_1, agd_bjarkeWins_1, agd_rasmus2Wins_1, 0, 0, 0);
            if(agd_k_5 == agd_rasmusWins_1)
            {
                agd_println("RASMUS WINS THE ENTIRE THING!");
            }
            else
            {
                if(agd_k_5 == agd_bjarkeWins_1)
                {
                    agd_println("BJARKE WINS THE ENTIRE THING!");
                }
                else
                {
                    if(agd_k_5 == agd_rasmus2Wins_1)
                    {
                        agd_println("JOHN WINS THE ENTIRE THING!");
                    }
                }
            }
            return false;
        }
        return true;
    }

    private static boolean agd_isOccopied_1(int agd_inDir_2, int agd_left_2)
    {
        if(agd_rasmusDirection_1 == 0)
        {
            return  !(agd_getGridColor(agd_rasmusX_1 - agd_left_2, agd_rasmusY_1 - agd_inDir_2).equals(agd_standardColor_1));
        }
        if(agd_rasmusDirection_1 == 1)
        {
            return  !(agd_getGridColor(agd_rasmusX_1 + agd_inDir_2, agd_rasmusY_1 - agd_left_2).equals(agd_standardColor_1));
        }
        if(agd_rasmusDirection_1 == 2)
        {
            return  !(agd_getGridColor(agd_rasmusX_1 + agd_left_2, agd_rasmusY_1 + agd_inDir_2).equals(agd_standardColor_1));
        }
        if(agd_rasmusDirection_1 == 3)
        {
            return  !(agd_getGridColor(agd_rasmusX_1 - agd_inDir_2, agd_rasmusY_1 + agd_left_2).equals(agd_standardColor_1));
        }
        agd_println("erroE2");
        return false;
    }

    private static int agd_mod_1(int agd_a_2, int agd_n_2)
    {
        return (agd_a_2 - (agd_n_2 * (agd_a_2 / agd_n_2)));
    }

    private static boolean agd_rasmusTron_1()
    {
        int agd_off_3 = 0;
        agd_off_3 = 4;
        int agd_one_3 = 0;
        int agd_two_3 = 0;
        int agd_three_3 = 0;
        int agd_zero_3 = 0;
        agd_one_3 = 0;
        agd_two_3 = 0;
        agd_three_3 = 0;
        agd_zero_3 = 0;
        int agd_c_3 = 0;
        agd_c_3 = 1;
        int agd_lookahead_3 = 0;
        agd_rasmusS_1 = agd_rasmusDirection_1;
        boolean agd_rset_3 = false;
        boolean agd_lset_3 = false;
        agd_rset_3 = false;
        agd_lset_3 = false;
        int agd_ol_3 = 0;
        int agd_or_3 = 0;
        agd_ol_3 = 35;
        agd_or_3 = 35;
        while (agd_c_3 < 15)
        {
            if(agd_isOccopied_1(0, agd_c_3) && agd_ol_3 == 35)
            {
                agd_ol_3 = agd_c_3;
                agd_lset_3 = true;
            }
            if(agd_isOccopied_1(0,  - agd_c_3) && agd_or_3 == 35)
            {
                agd_or_3 = agd_c_3;
                agd_rset_3 = true;
            }
            agd_c_3 = agd_c_3 + 1;
        }
        agd_lookahead_3 = 2;
        if(agd_isOccopied_1(1, 0))
        {
            if(agd_rasmusDirection_1 == 0)
            {
                if(agd_or_3 > agd_ol_3)
                {
                    agd_rasmusDirection_1 = 1;
                }
                else
                {
                    agd_rasmusDirection_1 = 3;
                }
            }
            else
            {
                if(agd_or_3 < agd_ol_3)
                {
                    agd_rasmusDirection_1 = agd_mod_1(agd_rasmusDirection_1 - 1, 4);
                }
                else
                {
                    agd_rasmusDirection_1 = agd_mod_1(agd_rasmusDirection_1 + 1, 4);
                }
            }
        }
        else
        {
            if(agd_isOccopied_1(2, 0))
            {
                if(agd_or_3 > 2 || agd_ol_3 > 2)
                {
                    if(agd_rasmusDirection_1 == 0)
                    {
                        if(agd_or_3 > agd_ol_3)
                        {
                            agd_rasmusDirection_1 = 1;
                        }
                        else
                        {
                            agd_rasmusDirection_1 = 3;
                        }
                    }
                    else
                    {
                        if(agd_or_3 < agd_ol_3)
                        {
                            agd_rasmusDirection_1 = agd_mod_1(agd_rasmusDirection_1 - 1, 4);
                        }
                        else
                        {
                            agd_rasmusDirection_1 = agd_mod_1(agd_rasmusDirection_1 + 1, 4);
                        }
                    }
                }
            }
            else
            {
                if(agd_isOccopied_1(3, 0))
                {
                    if(agd_or_3 > 3 || agd_ol_3 > 3)
                    {
                        if(agd_rasmusDirection_1 == 0)
                        {
                            if(agd_or_3 > agd_ol_3)
                            {
                                agd_rasmusDirection_1 = 1;
                            }
                            else
                            {
                                agd_rasmusDirection_1 = 3;
                            }
                        }
                        else
                        {
                            if(agd_or_3 < agd_ol_3)
                            {
                                agd_rasmusDirection_1 = agd_mod_1(agd_rasmusDirection_1 - 1, 4);
                            }
                            else
                            {
                                agd_rasmusDirection_1 = agd_mod_1(agd_rasmusDirection_1 + 1, 4);
                            }
                        }
                    }
                }
                else
                {
                    if(agd_isOccopied_1(4, 0))
                    {
                        if(agd_rasmusDirection_1 != 3)
                        {
                            if(agd_or_3 > 4 || agd_ol_3 > 4)
                            {
                                if(agd_rasmusDirection_1 == 0)
                                {
                                    if(agd_or_3 > agd_ol_3)
                                    {
                                        agd_rasmusDirection_1 = 1;
                                    }
                                    else
                                    {
                                        agd_rasmusDirection_1 = 3;
                                    }
                                }
                                else
                                {
                                    if(agd_or_3 < agd_ol_3)
                                    {
                                        agd_rasmusDirection_1 = agd_mod_1(agd_rasmusDirection_1 - 1, 4);
                                    }
                                    else
                                    {
                                        agd_rasmusDirection_1 = agd_mod_1(agd_rasmusDirection_1 + 1, 4);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        int agd_i_3 = 0;
        agd_i_3 = 0;
        while (agd_i_3 < 5)
        {
            if(agd_getGridColor(agd_rasmusX_1 + 1, agd_rasmusY_1).equals(agd_standardColor_1) && agd_rasmusDirection_1 == 1)
            {
                agd_setGridColor(agd_rasmusX_1 + 1, agd_rasmusY_1, "yellow");
                agd_rasmusX_1 = agd_rasmusX_1 + 1;
                if(agd_rasmusS_1 == 1)
                {
                    agd_rasmusC_1 = agd_rasmusC_1 + 1;
                }
                else
                {
                    agd_rasmusC_1 = 0;
                }
                return true;
            }
            else
            {
                if(agd_getGridColor(agd_rasmusX_1, agd_rasmusY_1 + 1).equals(agd_standardColor_1) && agd_rasmusDirection_1 == 2)
                {
                    agd_setGridColor(agd_rasmusX_1, agd_rasmusY_1 + 1, "yellow");
                    agd_rasmusY_1 = agd_rasmusY_1 + 1;
                    if(agd_rasmusS_1 == 2)
                    {
                        agd_rasmusC_1 = agd_rasmusC_1 + 1;
                    }
                    else
                    {
                        agd_rasmusC_1 = 0;
                    }
                    return true;
                }
                else
                {
                    if(agd_getGridColor(agd_rasmusX_1 - 1, agd_rasmusY_1).equals(agd_standardColor_1) && agd_rasmusDirection_1 == 3)
                    {
                        agd_setGridColor(agd_rasmusX_1 - 1, agd_rasmusY_1, "yellow");
                        agd_rasmusX_1 = agd_rasmusX_1 - 1;
                        if(agd_rasmusS_1 == 3)
                        {
                            agd_rasmusC_1 = agd_rasmusC_1 + 1;
                        }
                        else
                        {
                            agd_rasmusC_1 = 0;
                        }
                        return true;
                    }
                    else
                    {
                        if(agd_getGridColor(agd_rasmusX_1, agd_rasmusY_1 - 1).equals(agd_standardColor_1) && agd_rasmusDirection_1 == 0)
                        {
                            agd_setGridColor(agd_rasmusX_1, agd_rasmusY_1 - 1, "yellow");
                            agd_rasmusY_1 = agd_rasmusY_1 - 1;
                            if(agd_rasmusS_1 == 0)
                            {
                                agd_rasmusC_1 = agd_rasmusC_1 + 1;
                            }
                            else
                            {
                                agd_rasmusC_1 = 0;
                            }
                            return true;
                        }
                    }
                }
            }
            agd_i_3 = agd_i_3 + 1;
            agd_rasmusDirection_1 = agd_rasmusDirection_1 + 1;
            if(agd_rasmusDirection_1 > 3)
            {
                agd_rasmusDirection_1 = 0;
            }
            if(agd_i_3 > 4)
            {
                agd_setGridColor(agd_rasmusX_1, agd_rasmusY_1, "white");
                agd_rasmusDead_1 = true;
                agd_rasmusML_1 = 0;
                agd_numOfTronsLeft_1 = agd_numOfTronsLeft_1 - 1;
                return false;
            }
        }
        return true;
    }

    private static int agd_getHighest3_1(int agd_q_2, int agd_w_2, int agd_e_2)
    {
        int agd_ch_3 = 0;
        agd_ch_3 = agd_q_2;
        if(agd_ch_3 < agd_w_2)
        {
            agd_ch_3 = agd_w_2;
        }
        if(agd_ch_3 < agd_e_2)
        {
            agd_ch_3 = agd_e_2;
        }
        if(agd_ch_3 == agd_q_2)
        {
            return 0;
        }
        if(agd_ch_3 == agd_w_2)
        {
            return 1;
        }
        if(agd_ch_3 == agd_e_2)
        {
            return 2;
        }
        return 0;
    }

    private static boolean agd_bjarkeTron_1()
    {
        boolean agd_tried1_3 = false;
        boolean agd_tried2_3 = false;
        boolean agd_tried3_3 = false;
        boolean agd_tried4_3 = false;
        agd_tried1_3 = false;
        agd_tried2_3 = false;
        agd_tried3_3 = false;
        agd_tried4_3 = false;
        int agd_one_3 = 0;
        int agd_two_3 = 0;
        int agd_three_3 = 0;
        int agd_four_3 = 0;
        int agd_oneWall_3 = 0;
        int agd_twoWall_3 = 0;
        int agd_threeWall_3 = 0;
        int agd_fourWall_3 = 0;
        int agd_c_3 = 0;
        int agd_la_3 = 0;
        agd_la_3 = 50;
        agd_c_3 = 1;
        while (agd_c_3 < agd_la_3 + 1)
        {
            if(agd_getGridColor(agd_bjarkeTronX_1, agd_bjarkeTronY_1 + agd_c_3).equals(agd_standardColor_1))
            {
                if(agd_oneWall_3 < 1)
                {
                    agd_one_3 = agd_one_3 + 1;
                }
            }
            else
            {
                agd_oneWall_3 = 1;
            }
            if(agd_getGridColor(agd_bjarkeTronX_1 + agd_c_3, agd_bjarkeTronY_1).equals(agd_standardColor_1))
            {
                if(agd_twoWall_3 < 1)
                {
                    agd_two_3 = agd_two_3 + 1;
                }
            }
            else
            {
                agd_twoWall_3 = 1;
            }
            if(agd_getGridColor(agd_bjarkeTronX_1, agd_bjarkeTronY_1 - agd_c_3).equals(agd_standardColor_1))
            {
                if(agd_threeWall_3 < 1)
                {
                    agd_three_3 = agd_three_3 + 1;
                }
            }
            else
            {
                agd_threeWall_3 = 1;
            }
            if(agd_getGridColor(agd_bjarkeTronX_1 - agd_c_3, agd_bjarkeTronY_1).equals(agd_standardColor_1))
            {
                if(agd_fourWall_3 < 1)
                {
                    agd_four_3 = agd_four_3 + 1;
                }
            }
            else
            {
                agd_fourWall_3 = 1;
            }
            agd_c_3 = agd_c_3 + 1;
        }
        boolean agd_triedmove0_3 = false;
        boolean agd_triedmove1_3 = false;
        boolean agd_triedmove2_3 = false;
        boolean agd_triedmove3_3 = false;
        agd_triedmove0_3 = false;
        agd_triedmove1_3 = false;
        agd_triedmove2_3 = false;
        agd_triedmove3_3 = false;
        int agd_counter_3 = 0;
        agd_counter_3 = 0;
        while (agd_counter_3 <= 4)
        {
            if(agd_bjarkeDirection_1 == 0)
            {
                if(agd_bjarkeMoveTron_1(0, 1, agd_triedmove0_3, 2))
                {
                    return true;
                }
                else
                {
                    agd_triedmove0_3 = true;
                    if(agd_two_3 > agd_four_3)
                    {
                        agd_bjarkeDirection_1 = 1;
                    }
                    else
                    {
                        agd_bjarkeDirection_1 = 3;
                    }
                    if(agd_triedmove0_3)
                    {
                        agd_counter_3 = agd_counter_3 + 1;
                    }
                }
            }
            else
            {
                if(agd_bjarkeDirection_1 == 1)
                {
                    if(agd_bjarkeMoveTron_1(1, 0, agd_triedmove1_3, 2))
                    {
                        return true;
                    }
                    else
                    {
                        agd_triedmove1_3 = true;
                        if(agd_one_3 > agd_three_3)
                        {
                            agd_bjarkeDirection_1 = 0;
                        }
                        else
                        {
                            agd_bjarkeDirection_1 = 2;
                        }
                        if(agd_triedmove1_3)
                        {
                            agd_counter_3 = agd_counter_3 + 1;
                        }
                    }
                }
                else
                {
                    if(agd_bjarkeDirection_1 == 2)
                    {
                        if(agd_bjarkeMoveTron_1(0,  - 1, agd_triedmove2_3, 2))
                        {
                            return true;
                        }
                        else
                        {
                            agd_triedmove2_3 = true;
                            if(agd_two_3 > agd_four_3)
                            {
                                agd_bjarkeDirection_1 = 1;
                            }
                            else
                            {
                                agd_bjarkeDirection_1 = 3;
                            }
                            if(agd_triedmove2_3)
                            {
                                agd_counter_3 = agd_counter_3 + 1;
                            }
                        }
                    }
                    else
                    {
                        if(agd_bjarkeDirection_1 == 3)
                        {
                            if(agd_bjarkeMoveTron_1( - 1, 0, agd_triedmove3_3, 2))
                            {
                                return true;
                            }
                            else
                            {
                                agd_triedmove3_3 = true;
                                if(agd_one_3 > agd_three_3)
                                {
                                    agd_bjarkeDirection_1 = 0;
                                }
                                else
                                {
                                    agd_bjarkeDirection_1 = 2;
                                }
                                if(agd_triedmove3_3)
                                {
                                    agd_counter_3 = agd_counter_3 + 1;
                                }
                            }
                        }
                    }
                }
            }
        }
        agd_setGridColor(agd_bjarkeTronX_1, agd_bjarkeTronY_1, "white");
        agd_bjarkeDead_1 = true;
        agd_numOfTronsLeft_1 = agd_numOfTronsLeft_1 - 1;
        return false;
    }

    private static boolean agd_frontBlocked_1(int agd_n_2)
    {
        int agd_frontX_3 = 0;
        int agd_frontY_3 = 0;
        boolean agd_left_3 = false;
        boolean agd_right_3 = false;
        if(agd_bjarkeDirection_1 == 0)
        {
            agd_frontX_3 = agd_bjarkeTronX_1;
            agd_frontY_3 = agd_bjarkeTronY_1 + agd_n_2;
            if(agd_getGridColor(agd_frontX_3, agd_frontY_3).equals(agd_standardColor_1))
            {
                if(agd_getGridColor(agd_frontX_3 - 1, agd_frontY_3).equals(agd_standardColor_1))
                {
                    agd_left_3 = true;
                }
                else
                {
                }
                if(agd_getGridColor(agd_frontX_3 + 1, agd_frontY_3).equals(agd_standardColor_1))
                {
                    agd_right_3 = true;
                }
                else
                {
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            if(agd_bjarkeDirection_1 == 1)
            {
                agd_frontX_3 = agd_bjarkeTronX_1 + agd_n_2;
                agd_frontY_3 = agd_bjarkeTronY_1;
                if(agd_getGridColor(agd_frontX_3, agd_frontY_3).equals(agd_standardColor_1))
                {
                    if(agd_getGridColor(agd_frontX_3, agd_frontY_3 + 1).equals(agd_standardColor_1))
                    {
                        agd_left_3 = true;
                    }
                    else
                    {
                    }
                    if(agd_getGridColor(agd_frontX_3, agd_frontY_3 - 1).equals(agd_standardColor_1))
                    {
                        agd_right_3 = true;
                    }
                    else
                    {
                    }
                }
                else
                {
                    return false;
                }
            }
            else
            {
                if(agd_bjarkeDirection_1 == 2)
                {
                    agd_frontX_3 = agd_bjarkeTronX_1;
                    agd_frontY_3 = agd_bjarkeTronY_1 - agd_n_2;
                    if(agd_getGridColor(agd_frontX_3, agd_frontY_3).equals(agd_standardColor_1))
                    {
                        if(agd_getGridColor(agd_frontX_3 + 1, agd_frontY_3).equals(agd_standardColor_1))
                        {
                            agd_left_3 = true;
                        }
                        else
                        {
                        }
                        if(agd_getGridColor(agd_frontX_3 - 1, agd_frontY_3).equals(agd_standardColor_1))
                        {
                            agd_right_3 = true;
                        }
                        else
                        {
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    if(agd_bjarkeDirection_1 == 3)
                    {
                        agd_frontX_3 = agd_bjarkeTronX_1 - agd_n_2;
                        agd_frontY_3 = agd_bjarkeTronY_1;
                        if(agd_getGridColor(agd_frontX_3, agd_frontY_3).equals(agd_standardColor_1))
                        {
                            if(agd_getGridColor(agd_frontX_3, agd_frontY_3 - 1).equals(agd_standardColor_1))
                            {
                                agd_left_3 = true;
                            }
                            else
                            {
                            }
                            if(agd_getGridColor(agd_frontX_3, agd_frontY_3 + 1).equals(agd_standardColor_1))
                            {
                                agd_right_3 = true;
                            }
                            else
                            {
                            }
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }
        }
        if(agd_left_3 || agd_right_3)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    private static boolean agd_bjarkeMoveTron_1(int agd_n_2, int agd_m_2, boolean agd_blockage_2, int agd_step_2)
    {
        int agd_tmpx_3 = 0;
        int agd_tmpy_3 = 0;
        agd_tmpx_3 = agd_bjarkeTronX_1 + agd_n_2;
        agd_tmpy_3 = agd_bjarkeTronY_1 + agd_m_2;
        String agd_nextGridColor_3 = "";
        agd_nextGridColor_3 = agd_getGridColor(agd_tmpx_3, agd_tmpy_3);
        if(agd_nextGridColor_3.equals(agd_standardColor_1))
        {
            if( !(agd_blockage_2))
            {
                if(agd_frontBlocked_1(agd_step_2))
                {
                    return false;
                }
                else
                {
                    agd_bjarkeTronX_1 = agd_tmpx_3;
                    agd_bjarkeTronY_1 = agd_tmpy_3;
                    agd_setGridColor(agd_bjarkeTronX_1, agd_bjarkeTronY_1, "red");
                    return true;
                }
            }
            else
            {
                agd_bjarkeTronX_1 = agd_tmpx_3;
                agd_bjarkeTronY_1 = agd_tmpy_3;
                agd_setGridColor(agd_bjarkeTronX_1, agd_bjarkeTronY_1, "red");
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    private static int agd_getHeighestNumOfWins_1(int agd_a_2, int agd_b_2, int agd_c_2, int agd_d_2, int agd_e_2, int agd_f_2)
    {
        int agd_ch_3 = 0;
        agd_ch_3 = agd_a_2;
        if(agd_ch_3 < agd_b_2)
        {
            agd_ch_3 = agd_b_2;
        }
        if(agd_ch_3 < agd_c_2)
        {
            agd_ch_3 = agd_c_2;
        }
        if(agd_ch_3 < agd_d_2)
        {
            agd_ch_3 = agd_d_2;
        }
        if(agd_ch_3 < agd_e_2)
        {
            agd_ch_3 = agd_e_2;
        }
        if(agd_ch_3 < agd_f_2)
        {
            agd_ch_3 = agd_f_2;
        }
        return agd_ch_3;
    }

    private static boolean agd_rasmus2Tron_1()
    {
        int agd_off_3 = 0;
        agd_off_3 = 1;
        int agd_one_3 = 0;
        int agd_two_3 = 0;
        int agd_three_3 = 0;
        int agd_zero_3 = 0;
        int agd_one1_3 = 0;
        int agd_two1_3 = 0;
        int agd_three1_3 = 0;
        int agd_zero1_3 = 0;
        agd_one_3 = 0;
        agd_two_3 = 0;
        agd_three_3 = 0;
        agd_zero_3 = 0;
        agd_one1_3 = 0;
        agd_two1_3 = 0;
        agd_three1_3 = 0;
        agd_zero1_3 = 0;
        int agd_c_3 = 0;
        agd_c_3 = 0;
        while (agd_c_3 < 7)
        {
            if(agd_getGridColor(agd_rasmus2X_1 + agd_c_3, agd_rasmus2Y_1).equals(agd_standardColor_1) && agd_one1_3 == 0)
            {
                agd_one_3 = agd_c_3;
            }
            else
            {
                agd_one1_3 = 1;
            }
            if(agd_getGridColor(agd_rasmus2X_1, agd_rasmus2Y_1 + agd_c_3).equals(agd_standardColor_1) && agd_two1_3 == 0)
            {
                agd_two_3 = agd_c_3;
            }
            else
            {
                agd_two1_3 = 1;
            }
            if(agd_getGridColor(agd_rasmus2X_1 - agd_c_3, agd_rasmus2Y_1).equals(agd_standardColor_1) && agd_three1_3 == 0)
            {
                agd_three_3 = agd_c_3;
            }
            else
            {
                agd_two1_3 = 1;
            }
            if(agd_getGridColor(agd_rasmus2X_1, agd_rasmus2Y_1 - agd_c_3).equals(agd_standardColor_1) && agd_zero1_3 == 0)
            {
                agd_zero_3 = agd_c_3;
            }
            else
            {
                agd_two1_3 = 1;
            }
            agd_c_3 = agd_c_3 + 1;
        }
        if(agd_rasmus2Direction_1 == 0)
        {
            int agd_hz_5 = 0;
            agd_hz_5 = agd_getHighest3_1(agd_zero_3, agd_one_3, agd_three_3);
            if(agd_hz_5 == 0)
            {
                if(agd_one_3 - agd_off_3 > agd_zero_3)
                {
                    agd_rasmus2Direction_1 = 1;
                }
                else
                {
                    if(agd_three_3 - agd_off_3 > agd_zero_3)
                    {
                        agd_rasmus2Direction_1 = 3;
                    }
                    else
                    {
                        agd_rasmus2Direction_1 = 0;
                    }
                }
            }
            if(agd_hz_5 == 1)
            {
                agd_rasmus2Direction_1 = 1;
            }
            if(agd_hz_5 == 2)
            {
                agd_rasmus2Direction_1 = 3;
            }
        }
        if(agd_rasmus2Direction_1 == 1)
        {
            int agd_hz_5 = 0;
            agd_hz_5 = agd_getHighest3_1(agd_one_3, agd_zero_3, agd_two_3);
            if(agd_hz_5 == 0)
            {
                if(agd_zero_3 - agd_off_3 > agd_one_3)
                {
                    agd_rasmus2Direction_1 = 0;
                }
                else
                {
                    if(agd_two_3 - agd_off_3 > agd_one_3)
                    {
                        agd_rasmus2Direction_1 = 2;
                    }
                    else
                    {
                        agd_rasmus2Direction_1 = 1;
                    }
                }
            }
            if(agd_hz_5 == 1)
            {
                agd_rasmus2Direction_1 = 0;
            }
            if(agd_hz_5 == 2)
            {
                agd_rasmus2Direction_1 = 2;
            }
        }
        if(agd_rasmus2Direction_1 == 2)
        {
            int agd_hz_5 = 0;
            agd_hz_5 = agd_getHighest3_1(agd_two_3, agd_one_3, agd_three_3);
            if(agd_hz_5 == 0)
            {
                if(agd_one_3 - agd_off_3 > agd_two_3)
                {
                    agd_rasmus2Direction_1 = 1;
                }
                else
                {
                    if(agd_three_3 - agd_off_3 > agd_two_3)
                    {
                        agd_rasmus2Direction_1 = 3;
                    }
                    else
                    {
                        agd_rasmus2Direction_1 = 2;
                    }
                }
            }
            if(agd_hz_5 == 1)
            {
                agd_rasmus2Direction_1 = 1;
            }
            if(agd_hz_5 == 2)
            {
                agd_rasmus2Direction_1 = 3;
            }
        }
        if(agd_rasmus2Direction_1 == 3)
        {
            int agd_hz_5 = 0;
            agd_hz_5 = agd_getHighest3_1(agd_three_3, agd_zero_3, agd_two_3);
            if(agd_hz_5 == 0)
            {
                if(agd_zero_3 - agd_off_3 > agd_three_3)
                {
                    agd_rasmus2Direction_1 = 0;
                }
                else
                {
                    if(agd_two_3 - agd_off_3 > agd_three_3)
                    {
                        agd_rasmus2Direction_1 = 2;
                    }
                    else
                    {
                        agd_rasmus2Direction_1 = 3;
                    }
                }
            }
            if(agd_hz_5 == 1)
            {
                agd_rasmus2Direction_1 = 0;
            }
            if(agd_hz_5 == 2)
            {
                agd_rasmus2Direction_1 = 2;
            }
        }
        int agd_i_3 = 0;
        agd_i_3 = 0;
        while (agd_i_3 < 5)
        {
            if(agd_getGridColor(agd_rasmus2X_1 + 1, agd_rasmus2Y_1).equals(agd_standardColor_1) && agd_rasmus2X_1 <= agd_getWidth() - 1 && agd_rasmus2Direction_1 == 1)
            {
                agd_setGridColor(agd_rasmus2X_1 + 1, agd_rasmus2Y_1, "cyan");
                agd_rasmus2X_1 = agd_rasmus2X_1 + 1;
                return true;
            }
            else
            {
                if(agd_getGridColor(agd_rasmus2X_1, agd_rasmus2Y_1 + 1).equals(agd_standardColor_1) && agd_rasmus2Y_1 <= agd_getWidth() - 1 && agd_rasmus2Direction_1 == 2)
                {
                    agd_setGridColor(agd_rasmus2X_1, agd_rasmus2Y_1 + 1, "cyan");
                    agd_rasmus2Y_1 = agd_rasmus2Y_1 + 1;
                    return true;
                }
                else
                {
                    if(agd_getGridColor(agd_rasmus2X_1 - 1, agd_rasmus2Y_1).equals(agd_standardColor_1) && agd_rasmus2X_1 > 0 && agd_rasmus2Direction_1 == 3)
                    {
                        agd_setGridColor(agd_rasmus2X_1 - 1, agd_rasmus2Y_1, "cyan");
                        agd_rasmus2X_1 = agd_rasmus2X_1 - 1;
                        return true;
                    }
                    else
                    {
                        if(agd_getGridColor(agd_rasmus2X_1, agd_rasmus2Y_1 - 1).equals(agd_standardColor_1) && agd_rasmus2Y_1 > 0 && agd_rasmus2Direction_1 == 0)
                        {
                            agd_setGridColor(agd_rasmus2X_1, agd_rasmus2Y_1 - 1, "cyan");
                            agd_rasmus2Y_1 = agd_rasmus2Y_1 - 1;
                            return true;
                        }
                    }
                }
            }
            agd_i_3 = agd_i_3 + 1;
            agd_rasmus2Direction_1 = agd_rasmus2Direction_1 + 1;
            if(agd_rasmus2Direction_1 > 3)
            {
                agd_rasmus2Direction_1 = 0;
            }
            if(agd_i_3 > 4)
            {
                agd_setGridColor(agd_rasmus2X_1, agd_rasmus2Y_1, "white");
                agd_rasmus2Dead_1 = true;
                agd_numOfTronsLeft_1 = agd_numOfTronsLeft_1 - 1;
                return false;
            }
        }
        return true;
    }

    private static boolean agd_roundFinished_1()
    {
        if(agd_numOfTronsLeft_1 < 1)
        {
            agd_ties_1 = agd_ties_1 + 1;
            agd_winner_1 = "Tie";
        }
        else
        {
            if( !(agd_rasmusDead_1))
            {
                agd_winner_1 = "Rasmus";
            }
            if( !(agd_bjarkeDead_1))
            {
                agd_winner_1 = "Bjarke";
            }
            if( !(agd_rasmus2Dead_1))
            {
                agd_winner_1 = "John";
            }
        }
        agd_println("The winner is " + agd_winner_1);
        if(agd_winner_1.equals("Rasmus"))
        {
            agd_rasmusWins_1 = agd_rasmusWins_1 + 1;
        }
        if(agd_winner_1.equals("Bjarke"))
        {
            agd_bjarkeWins_1 = agd_bjarkeWins_1 + 1;
        }
        if(agd_winner_1.equals("John"))
        {
            agd_rasmus2Wins_1 = agd_rasmus2Wins_1 + 1;
        }
        agd_println("Rasmus' Wins: " + agd_intToString(agd_rasmusWins_1) + ". Bjarkes Wins: " + agd_intToString(agd_bjarkeWins_1) + ". Ties: " + agd_intToString(agd_ties_1) + ".");
        agd_countOfGames_1 = agd_countOfGames_1 + 1;
        agd_clearGrid();
        agd_bjarkeDead_1 = false;
        agd_rasmusDead_1 = false;
        agd_bjarkeTronY_1 = agd_randomInt(0, agd_getHeight() - 1);
        agd_bjarkeTronX_1 = agd_randomInt(0, agd_getWidth() - 1);
        agd_bjarkeDirection_1 = agd_randomInt(0, 3);
        agd_setGridColor(agd_bjarkeTronX_1, agd_bjarkeTronY_1, "red");
        agd_rasmusX_1 = agd_randomInt(0, agd_getWidth() - 1);
        agd_rasmusY_1 = agd_randomInt(0, agd_getHeight() - 1);
        agd_rasmusDirection_1 = agd_randomInt(0, 3);
        agd_setGridColor(agd_rasmusX_1, agd_rasmusY_1, "yellow");
        agd_rasmus2X_1 = agd_randomInt(0, agd_getWidth() - 1);
        agd_rasmus2Y_1 = agd_randomInt(0, agd_getHeight() - 1);
        agd_rasmus2Direction_1 = agd_randomInt(0, 3);
        agd_numOfTronsLeft_1 = agd_amountOfTrons_1;
        agd_ticks_1 = 0;
        return true;
    }
}
