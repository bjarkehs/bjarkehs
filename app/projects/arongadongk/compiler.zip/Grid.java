//package library;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JPanel;

public class Grid extends JPanel {

	public Cell[][] cells;
	public int x = 80;
	public int y = 50;
	public int totalWidth;
	public int totalHeight;

	public boolean border = true;
	public Color borderColor = new Color(41, 156, 232);
	public Color backgroundColor = new Color(3, 9,85);
	private static final long serialVersionUID = 1L;
	
	public Grid() {
		totalWidth = x * Cell.width;
		totalHeight = y * Cell.height;
		cells = new Cell[x][y];

		
		this.setPreferredSize(new Dimension(totalWidth + 10 ,totalHeight +10));
		
		this.reset();
		

	}

	
	
	public void paintComponent(Graphics g){
		
	//	super.paintComponent(g);
		int borderWidth;
		g.setColor(Color.white);
		g.fillRect(-110, -110, 1000, 1000);
		
		
		for (int i = 0; i < x; i++) {
			
			for (int j = 0; j < y; j++) {
				
				if (border){
					g.setColor(borderColor);
					borderWidth = 1;
					g.drawRect( 5 +i * Cell.width, 5+ j * Cell.height,Cell.width, Cell.height);
				} else {
					borderWidth = 0;
				}
				
				g.setColor(cells[i][j].getColor());
				g.fillRect(5+ i * Cell.width + borderWidth ,5+  j * Cell.height + borderWidth, Cell.width - borderWidth, Cell.height- borderWidth);
			}
			//System.out.println(cells[i][0].getColor());
		}
		
		
		
	}
	
	public void setBorderColor(Color c)
	{
		borderColor = c;
	}

	public void setGridColor(int posX, int posY, Color c){
		cells[posX][posY].setColor(c);
		repaint();
	}
	
	public Color getGridColor(int posX, int posY) {
		return cells[posX][posY].getColor();
	}
/*
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	*/
	boolean isCellOcupied(int posX, int posY){
		if(posX >= getX() || posY >= getY() || posX < 0 || posY < 0)
		{
			return true;
		}
		if(getGridColor(posX, posY) == backgroundColor)
		{
			return false;
		}
		return true;
	}
	
	public void reset() {
		for (int i = 0; i < x; i++) {
			for (int j = 0; j < y; j++) {
				cells[i][j] = new Cell(backgroundColor);
				//System.out.println("woo " + i + " " + j);
			}
		}
	}
}

